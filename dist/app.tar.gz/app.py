import flet as ft
from main import Main

 
def main():
    #ft.app(target=Main, view = ft.WEB_BROWSER)
    ft.app(target=Main)
    
if __name__ == "__main__":
    main()
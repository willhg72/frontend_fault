from flet as ft

class Main_styles:
    
    def principal_page_style(self):
        return {
            'page.padding': 0,
             
        }
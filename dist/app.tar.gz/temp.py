


# next define a class for the data table
class DataTable(ft.DataTable):
    def __init_(self, df: dict[str, float]):
        self.styles = CoordinatesStyles()
        self.df = df
        super().__init__(**self.styles.data_table_styles)
    #     self.build()

    # def build(self):
    #     self.df =  self.fetch()
    #     #print(self.df.values())
    #     pass


    def fill_data_table(self):
        #clear the data table rows, for new/update batch
        self.rows = []
        # check dict data type to understand following loop
        for values in self.df.values():
            # create a new DataRow
            data = ft.DataRow()
            data.cells = [
                ft.DataCell(
                    ft.Text(value, color='red'))
                for value in values.values()
            ]
            self.rows.append(data)

        self.update()
        self.page.update()
        #print(self.df.values())
        
        
        
        
        
    def fetch_data(self,e: ft.HoverEvent):
        self.coordinates_response.controls = []
        self.data = FetchTectonicFaults(self.coordinates_latitude.value, self.coordinates_longitude.value)
        self.distances = self.data.get_distances()
        self.aux = DataTable(df=self.distances)
        # for fault,distance in self.distances.items():
        #     self.coordinates_response.controls.append(
        #         self.render_distance_component(fault,distance),
        #     )
        self.coordinates_response.controls.append(self.aux)
        return self.coordinates_response

    def render_distance_component(self,fault: str, distance:float):
        return ft.Row(
            controls=[
                ft.Text(fault),
                ft.Text(value=str(distance)),
            ],
            alignment="spaceBetween",

            data=[fault,distance]
        )